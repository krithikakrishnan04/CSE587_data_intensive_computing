## SF Crime

This is the code for my entry to the [SF Crime Kaggle competition](
https://www.kaggle.com/c/sf-crime).

I wrote a blog post about it: [My entry to the Kaggle SF crime classification competition using
Apache Spark](
https://benfradet.github.io/blog/2016/06/08/SF-crime-classification-with-Apache-Spark).

In [bin](bin) you'll find a submit script which will run everything for you.
You can find the code for the job in [SFCrime.scala](
src/main/scala/io/github/benfradet/SFCrime.scala).
